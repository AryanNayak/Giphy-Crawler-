import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import axios from "axios";
import TextField from "@material-ui/core/TextField";
import {
  Nav,
  Navbar,
  Container,
  Row,
  Col,
  Form,
  ListGroup,
} from "react-bootstrap";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import "./loader.css";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`nav-tabpanel-${index}`}
      aria-labelledby={`nav-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  table: {
    minWidth: 650,
  },
}));

export default function NavTabs() {

  const classes = useStyles();

  const [input, setInput] = useState("loading");
  const [data, setData] = useState([]);

  const handleOnClick = () => {
    
    axios
      .get("https://api.giphy.com/v1/gifs/trending", {
        params: {
          api_key: "XwmHCisyv9OKaVF7FLJ3EdsDJasP42hH",
          limit: 100
        }})
        .then((response) => {
        setData(response.data);
        console.log(response)        
      });

  };


  return (
    <div className={classes.root}>
      <Navbar position="static" style = {{background: "black"}}>
       
      </Navbar>
      <TabPanel  >
        <Row>
          <Col xs={7}>

            <TextField
              id="standard-full-width"
              label="Tag"
              style={{ margin: 8, left: "100px", color: "white" }}
              placeholder="Enter the Tag"
              helperText="Welcome to Giphy Crawler!"
              fullWidth
              margin="normal"
              onChange={(e) => setInput(e.target.value)}
            />
          </Col>
          <Col>
            <Button
               onClick={() => handleOnClick()}
              variant="contained"
              style={{ right: "20px", top: "20px", height: "50px" }}
            >
              {" "}
            Search
            </Button>
          </Col>
        </Row>
        </TabPanel>
        <div>
        { [data].map(el => {
      return (
        <div key={el.id} className="gif">
          <img src={el.url} />
          {/* {console.log(el)} */}
        </div>
      );
    })}
    </div>
    </div>
  );
}

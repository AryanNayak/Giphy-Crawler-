import logo from './logo.svg';
import './App.css';
import Search from './search.js';

function App() {
  return (
    <div className="App">
  <Search></Search>
    </div>
  );
}

export default App;
